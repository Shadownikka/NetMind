#!/usr/bin/env python3
"""
NetMind Cloud Sync Module
─────────────────────────
Handles bidirectional communication between the local NetMind desktop tool
and the NetMind web server using the user's API key.

Architecture (Push Model):
  • Every 5 seconds: POST /api/tool/push  → live snapshot (devices, bandwidth, status)
  • Every 3 seconds: GET  /api/tool/commands → pending commands from dashboard
  • After executing: POST /api/tool/commands/:id/ack → acknowledge completion

API Key Storage:
  Stored encrypted at ~/.netmind/api_key using Fernet symmetric encryption.
  The encryption key is derived from a machine-specific secret (hostname + mac).
  This means the key cannot simply be copy-pasted from one machine to another
  without re-entering it — it is tied to the installation.
"""

import os
import json
import time
import hashlib
import socket
import threading
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path

# ── Key storage path ──────────────────────────────────────────────────────────
_KEY_DIR  = Path.home() / '.netmind'
_KEY_FILE = _KEY_DIR / 'api_key'

# ── Encryption helpers (Fernet if available, else XOR fallback) ───────────────

def _machine_secret() -> bytes:
    """Derive a machine-specific key for encrypting the stored API token."""
    hostname = socket.gethostname()
    try:
        import uuid
        mac = str(uuid.getnode())
    except Exception:
        mac = 'netmind_default'
    raw = f'netmind-{hostname}-{mac}-cloud-sync'
    return hashlib.sha256(raw.encode()).digest()  # 32 bytes → valid Fernet key base

def _fernet():
    """Return a Fernet instance keyed to this machine, or None if unavailable."""
    try:
        from cryptography.fernet import Fernet
        import base64
        key_b64 = base64.urlsafe_b64encode(_machine_secret())
        return Fernet(key_b64)
    except ImportError:
        return None

def _xor_crypt(data: bytes, key: bytes) -> bytes:
    """Simple XOR cipher as fallback when cryptography library is absent."""
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))

def save_api_key(token: str) -> None:
    """Encrypt and persist the API token to disk."""
    _KEY_DIR.mkdir(parents=True, exist_ok=True)
    f = _fernet()
    raw = token.encode()
    if f:
        encrypted = f.encrypt(raw)
    else:
        encrypted = _xor_crypt(raw, _machine_secret())
    _KEY_FILE.write_bytes(encrypted)
    # Restrict permissions — only owner can read
    try:
        os.chmod(_KEY_FILE, 0o600)
    except Exception:
        pass

def load_api_key() -> str | None:
    """Load and decrypt the stored API token. Returns None if not found."""
    if not _KEY_FILE.exists():
        return None
    try:
        encrypted = _KEY_FILE.read_bytes()
        f = _fernet()
        if f:
            raw = f.decrypt(encrypted)
        else:
            raw = _xor_crypt(encrypted, _machine_secret())
        return raw.decode().strip()
    except Exception:
        return None

def delete_api_key() -> None:
    """Remove stored API key from disk."""
    try:
        _KEY_FILE.unlink(missing_ok=True)
    except Exception:
        pass


# ── HTTP helpers (stdlib only — no requests dependency) ───────────────────────

def _http(method: str, url: str, token: str, body: dict | None = None,
          timeout: int = 8) -> tuple[int, dict]:
    """Minimal HTTP client using stdlib urllib. Returns (status_code, json_body)."""
    data = json.dumps(body).encode() if body is not None else None
    headers = {'Content-Type': 'application/json', 'User-Agent': 'NetMind-Desktop/1.0'}
    if token:
        headers['X-NetMind-Token'] = token
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode())
        except Exception:
            body = {'error': str(e)}
        return e.code, body
    except Exception as e:
        return 0, {'error': str(e)}


# ── Main CloudSync class ──────────────────────────────────────────────────────

class CloudSync:
    """
    Background cloud sync service for the NetMind desktop app.

    Usage:
        sync = CloudSync(server_url='https://your-server.com')
        sync.set_controller(controller)   # BandwidthController
        sync.set_monitor(monitor)         # TrafficMonitor
        sync.set_devices(devices)         # devices dict
        sync.start()
        # ... when done:
        sync.stop()
    """

    PUSH_INTERVAL    = 5   # seconds between data pushes
    COMMAND_INTERVAL = 3   # seconds between command polls

    def __init__(self, server_url: str = 'https://backend-netmindweb.onrender.com'):
        self.server_url  = server_url.rstrip('/')
        self._token      = load_api_key()
        self._monitor    = None
        self._controller = None
        self._devices    = {}
        self._running    = False
        self._push_thread    = None
        self._command_thread = None
        self._lock       = threading.Lock()

        # Status tracking
        self.status          = 'disconnected'   # 'disconnected' | 'connecting' | 'online' | 'error'
        self.last_push_at    = None
        self.last_error      = None
        self.push_count      = 0
        self.commands_executed = 0

        # Callbacks — set these to update the GUI
        self.on_status_change = None   # callable(status: str)
        self.on_command       = None   # callable(command: str, payload: dict, success: bool)

    # ── Configuration setters ─────────────────────────────────────────────────

    def set_token(self, token: str) -> None:
        """Set API token and persist it to disk."""
        with self._lock:
            self._token = token
        save_api_key(token)

    def get_token(self) -> str | None:
        with self._lock:
            return self._token

    def set_monitor(self, monitor) -> None:
        self._monitor = monitor

    def set_controller(self, controller) -> None:
        self._controller = controller

    def set_devices(self, devices: dict) -> None:
        self._devices = devices

    def set_server_url(self, url: str) -> None:
        self.server_url = url.rstrip('/')

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._push_thread = threading.Thread(
            target=self._push_loop, daemon=True, name='NM-CloudPush')
        self._command_thread = threading.Thread(
            target=self._command_loop, daemon=True, name='NM-CloudCmd')
        self._push_thread.start()
        self._command_thread.start()
        print('[CloudSync] Started — push every 5s, commands every 3s')

    def stop(self) -> None:
        self._running = False
        print('[CloudSync] Stopped')

    def is_running(self) -> bool:
        return self._running

    def test_connection(self) -> tuple[bool, str]:
        """Test connectivity. Returns (ok, message)."""
        token = self.get_token()
        if not token:
            return False, 'No API key set.'
        code, body = _http('POST', f'{self.server_url}/api/tool/push', token, {
            'devices': [], 'bandwidth': {}, 'status': {'test': True}, 'allocations': []
        }, timeout=5)
        if code == 200:
            return True, 'Connected successfully.'
        elif code == 401:
            return False, 'Invalid API key — check your dashboard.'
        elif code == 0:
            return False, f'Cannot reach server: {body.get("error","timeout")}'
        else:
            return False, f'Server error {code}: {body.get("error","")}'

    def link_account(self, email: str, password: str) -> tuple[bool, str]:
        """
        Link this desktop installation to a NetMind account using email + password.
        Generates a unique local token, registers it server-side, then saves it.
        No copy-paste required.
        """
        import secrets
        # Generate a fresh random token tied to this installation
        raw = secrets.token_hex(8).upper()
        local_token = f'NM-{raw[0:4]}-{raw[4:8]}-{raw[8:12]}-{raw[12:16]}'

        body = {
            'email':      email,
            'password':   password,
            'tool_token': local_token,
        }
        code, resp = _http('POST', f'{self.server_url}/api/tool/register-auto',
                           token='', body=body, timeout=10)

        if code == 200 and resp.get('ok'):
            # Save the token — it's now registered in the DB
            self.set_token(local_token)
            self._set_status('online')
            return True, f'Linked successfully! Token saved. Syncing every 5s.'
        elif code == 401:
            return False, 'Wrong email or password.'
        elif code == 0:
            return False, f'Cannot reach server: {resp.get("error", "timeout")}'
        else:
            return False, f'Server error {code}: {resp.get("error", "")}'

    # ── Data push ─────────────────────────────────────────────────────────────

    def _build_snapshot(self) -> dict:
        """Build the snapshot payload from current monitor/controller state."""
        devices_list = []
        bandwidth    = {'total_down_kbps': 0, 'total_up_kbps': 0}
        status_info  = {
            'monitoring': self._monitor is not None and getattr(self._monitor, 'running', False),
            'device_count': len(self._devices),
            'limited_count': 0,
            'blocked_count': 0,
        }
        allocations = []

        try:
            stats  = self._monitor.get_current_stats() if self._monitor else {}
            limits = self._controller.limits           if self._controller else {}

            total_down = 0.0
            total_up   = 0.0

            for ip, info in self._devices.items():
                usage = stats.get(ip, {'up': 0.0, 'down': 0.0})
                down_kbps = round(usage.get('down', 0.0), 2)
                up_kbps   = round(usage.get('up',   0.0), 2)
                total_down += down_kbps
                total_up   += up_kbps

                is_limited = ip in limits
                is_blocked = is_limited and limits[ip].get('down', 999) <= 1

                if is_blocked:
                    dev_status = 'blocked'
                    status_info['blocked_count'] += 1
                elif is_limited:
                    dev_status = 'limited'
                    status_info['limited_count'] += 1
                elif down_kbps > 10 or up_kbps > 10:
                    dev_status = 'active'
                else:
                    dev_status = 'idle'

                device_entry = {
                    'ip':       ip,
                    'mac':      info.get('mac', ''),
                    'name':     info.get('name', f'Device-{ip.split(".")[-1]}'),
                    'down_kbps': down_kbps,
                    'up_kbps':   up_kbps,
                    'status':    dev_status,
                }
                devices_list.append(device_entry)

                if is_limited:
                    allocations.append({
                        'ip':        ip,
                        'down_kbps': limits[ip].get('down', 0),
                        'up_kbps':   limits[ip].get('up', 0),
                        'type':      'blocked' if is_blocked else 'limited',
                    })

            bandwidth = {
                'total_down_kbps': round(total_down, 2),
                'total_up_kbps':   round(total_up,   2),
                'total_down_mbps': round(total_down * 8 / 1000, 3),
                'total_up_mbps':   round(total_up   * 8 / 1000, 3),
            }

        except Exception as e:
            print(f'[CloudSync] Snapshot build error: {e}')

        return {
            'devices':     devices_list,
            'bandwidth':   bandwidth,
            'status':      status_info,
            'allocations': allocations,
        }

    def _push_loop(self) -> None:
        while self._running:
            token = self.get_token()
            if token:
                try:
                    snapshot = self._build_snapshot()
                    code, body = _http('POST', f'{self.server_url}/api/tool/push', token, snapshot)
                    if code == 200:
                        self.last_push_at = time.time()
                        self.push_count  += 1
                        if self.status != 'online':
                            self._set_status('online')
                    elif code == 401:
                        self._set_status('error')
                        self.last_error = 'Invalid API key.'
                    elif code == 0:
                        if self.status == 'online':
                            self._set_status('connecting')
                        self.last_error = body.get('error', 'connection failed')
                    else:
                        self.last_error = f'Push failed: {code}'
                except Exception as e:
                    self.last_error = str(e)
            else:
                if self.status != 'disconnected':
                    self._set_status('disconnected')

            time.sleep(self.PUSH_INTERVAL)

    # ── Command polling + execution ───────────────────────────────────────────

    def _command_loop(self) -> None:
        while self._running:
            token = self.get_token()
            if token and self._controller:
                try:
                    code, body = _http('GET', f'{self.server_url}/api/tool/commands', token)
                    if code == 200:
                        for cmd in body.get('commands', []):
                            self._execute_command(cmd, token)
                except Exception:
                    pass
            time.sleep(self.COMMAND_INTERVAL)

    def _execute_command(self, cmd: dict, token: str) -> None:
        """Execute a single command from the dashboard."""
        cmd_id   = cmd['id']
        command  = cmd['command']
        payload  = cmd.get('payload', {})
        success  = False

        try:
            if command == 'limit':
                ip       = payload.get('ip', '')
                down_k   = int(payload.get('down_kbps', 512))
                up_k     = int(payload.get('up_kbps',   256))
                if ip and self._controller:
                    success = bool(self._controller.apply_limit(ip, down_k, up_k))
                    print(f'[CloudSync] CMD limit {ip} → ↓{down_k} ↑{up_k}KB/s  ok={success}')

            elif command == 'block':
                ip = payload.get('ip', '')
                if ip and self._controller:
                    success = bool(self._controller.apply_limit(ip, 1, 1))
                    print(f'[CloudSync] CMD block {ip}  ok={success}')

            elif command == 'remove_limit':
                ip = payload.get('ip', '')
                if ip and self._controller and ip in self._controller.limits:
                    self._controller.remove_limit(ip)
                    success = True
                    print(f'[CloudSync] CMD remove_limit {ip}  ok=True')

            elif command == 'restore_all':
                if self._controller:
                    for ip in list(self._controller.limits.keys()):
                        self._controller.remove_limit(ip)
                    success = True
                    print('[CloudSync] CMD restore_all executed')

            elif command == 'trust':
                # Trust commands are handled by the GUI — just ack
                success = True

            elif command == 'untrust':
                success = True

            else:
                print(f'[CloudSync] Unknown command: {command}')

        except Exception as e:
            print(f'[CloudSync] Command {command} error: {e}')
            success = False

        # ACK the command back to the server
        ack_body = {'success': success}
        if not success:
            ack_body['error'] = self.last_error or 'execution failed'
        _http('POST', f'{self.server_url}/api/tool/commands/{cmd_id}/ack', token, ack_body)

        self.commands_executed += 1
        if self.on_command:
            try:
                self.on_command(command, payload, success)
            except Exception:
                pass

    def _set_status(self, new_status: str) -> None:
        self.status = new_status
        if self.on_status_change:
            try:
                self.on_status_change(new_status)
            except Exception:
                pass

    def get_status_info(self) -> dict:
        return {
            'status':            self.status,
            'token_set':         bool(self.get_token()),
            'last_push_at':      self.last_push_at,
            'push_count':        self.push_count,
            'commands_executed': self.commands_executed,
            'last_error':        self.last_error,
        }
