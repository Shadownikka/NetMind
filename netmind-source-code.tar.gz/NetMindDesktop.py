#!/usr/bin/env python3
"""
NetMind Desktop — Fully Native PyQt6 Application
No web server. No browser. Pure Qt widgets driving the network modules directly.

Run: sudo python3 NetMindDesktop.py
"""
import sys, os, time, signal, webbrowser, pathlib, shutil, threading

_ROOT = os.path.dirname(os.path.abspath(__file__))
# Add core/ to path so all engine modules are importable without change
sys.path.insert(0, os.path.join(_ROOT, 'core'))
sys.path.insert(0, _ROOT)

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QLabel, QPushButton, QTextEdit, QLineEdit,
    QFrame, QStackedWidget, QTableWidget, QTableWidgetItem,
    QHeaderView, QScrollArea, QSplitter, QProgressBar,
    QSystemTrayIcon, QMenu, QSizePolicy, QMessageBox,
    QSplashScreen, QAbstractItemView,
)
from PyQt6.QtCore import (
    Qt, QTimer, QThread, pyqtSignal, QSize, QUrl, pyqtSlot,
)
from PyQt6.QtGui import (
    QIcon, QPixmap, QColor, QPainter, QFont, QAction,
    QGuiApplication, QPen, QBrush, QLinearGradient,
    QFontDatabase,
)

# ── Base dir ────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    BASE = sys._MEIPASS          # type: ignore
else:
    BASE = os.path.dirname(os.path.abspath(__file__))

# ── Colours ─────────────────────────────────────────────────────────
BG0, BG1, BG2, BG3 = "#07090f", "#0d1117", "#141922", "#1c2333"
C1, C2, C3, C4     = "#00d4ff", "#7c3aed", "#00ffa3", "#f59e0b"
DANGER, TEXT, TEXT2 = "#ef4444", "#e2e8f0", "#94a3b8"

DARK_STYLE = f"""
QWidget {{ background:{BG0}; color:{TEXT}; font-family:Inter,system-ui,sans-serif; font-size:13px; }}
QFrame  {{ background:transparent; }}
QLabel  {{ background:transparent; }}
QLineEdit, QTextEdit {{
    background:{BG2}; border:1px solid rgba(255,255,255,.08);
    border-radius:8px; color:{TEXT}; padding:8px 12px; font-size:13px;
}}
QLineEdit:focus, QTextEdit:focus {{
    border-color:{C1}; outline:none;
}}
QScrollBar:vertical {{
    background:{BG1}; width:6px; border:none; border-radius:3px;
}}
QScrollBar::handle:vertical {{
    background:#242d3e; border-radius:3px; min-height:20px;
}}
QScrollBar::handle:vertical:hover {{ background:{C1}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height:0; }}
QScrollBar:horizontal {{ height:0; }}
QTableWidget {{
    background:{BG1}; border:none; gridline-color:rgba(255,255,255,.05);
    selection-background-color:rgba(0,212,255,.12);
}}
QTableWidget::item {{ padding:6px 10px; border-bottom:1px solid rgba(255,255,255,.04); }}
QTableWidget::item:selected {{ background:rgba(0,212,255,.12); color:{TEXT}; }}
QHeaderView::section {{
    background:{BG2}; color:{C1}; font-size:11px; font-weight:700;
    text-transform:uppercase; letter-spacing:0.8px;
    padding:8px 10px; border:none; border-bottom:1px solid rgba(255,255,255,.07);
}}
QToolTip {{
    background:{BG2}; color:{TEXT}; border:1px solid rgba(0,212,255,.3);
    border-radius:6px; padding:6px 10px;
}}
QMenu {{
    background:{BG2}; border:1px solid rgba(255,255,255,.1); border-radius:8px; padding:4px;
}}
QMenu::item {{ padding:8px 20px; border-radius:4px; }}
QMenu::item:selected {{ background:rgba(0,212,255,.15); }}
QSplitter::handle {{ background:rgba(255,255,255,.05); width:1px; height:1px; }}
QMessageBox {{ background:{BG1}; }}
"""

# ── Helpers ─────────────────────────────────────────────────────────
def btn(text, style="primary", small=False):
    b = QPushButton(text)
    pad = "5px 13px" if small else "9px 18px"
    sz  = "12px" if small else "13px"
    base = f"font-size:{sz};font-weight:600;border-radius:8px;padding:{pad};border:none;"
    styles = {
        "primary": f"{base}background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C1},stop:1 {C2});color:#fff;",
        "success": f"{base}background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C3},stop:1 #00cc82);color:#0a0f1a;",
        "danger":  f"{base}background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {DANGER},stop:1 #c02020);color:#fff;",
        "outline": f"{base}background:transparent;color:{TEXT2};border:1px solid rgba(255,255,255,.12);",
        "ghost":   f"{base}background:rgba(255,255,255,.05);color:{TEXT2};",
    }
    b.setStyleSheet(styles.get(style, styles["ghost"]))
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    return b

def card(parent=None):
    f = QFrame(parent)
    f.setStyleSheet(f"""
        QFrame {{
            background:{BG2}; border:1px solid rgba(255,255,255,.07);
            border-radius:14px;
        }}
    """)
    return f

def lbl(text, size=13, bold=False, color=TEXT):
    l = QLabel(text)
    w = 700 if bold else 400
    l.setStyleSheet(f"color:{color};font-size:{size}px;font-weight:{w};background:transparent;")
    return l

def sep():
    f = QFrame()
    f.setFrameShape(QFrame.Shape.HLine)
    f.setStyleSheet("background:rgba(255,255,255,.06);margin:4px 0;max-height:1px;")
    return f

def make_icon(size=64):
    px = QPixmap(size, size)
    px.fill(Qt.GlobalColor.transparent)
    p = QPainter(px)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, size, size)
    g.setColorAt(0, QColor(C1)); g.setColorAt(1, QColor(C2))
    p.setBrush(QBrush(g)); p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(4, 4, size-8, size-8, size//4, size//4)
    p.setPen(QPen(QColor("white")))
    f = QFont("Inter", size//3, QFont.Weight.Black)
    p.setFont(f)
    p.drawText(px.rect(), Qt.AlignmentFlag.AlignCenter, "N")
    p.end()
    return QIcon(px)

GRAFANA_URL = "http://localhost:3000"

# ═══════════════════════════════════════════════════════════════════
# Worker threads
# ═══════════════════════════════════════════════════════════════════

class InitWorker(QThread):
    done   = pyqtSignal(dict)
    error  = pyqtSignal(str)
    def run(self):
        try:
            import scapy.all as scapy
            from tool import (get_gateway_ip, get_default_interface,
                              get_subnet_cidr, discover_clients,
                              TrafficMonitor, BandwidthController,
                              ConnectionTracker, enable_ip_forwarding)
            iface   = get_default_interface()
            gw_ip   = get_gateway_ip()
            my_ip   = scapy.get_if_addr(iface)
            gw_mac  = (scapy.getmacbyip(gw_ip) or "").lower()
            my_mac  = scapy.get_if_hwaddr(iface).lower()
            clients = discover_clients(get_subnet_cidr(iface))
            devices = {}
            for c in clients:
                ip = c["ip"]; mac = (c.get("mac") or "").lower()
                if ip in (gw_ip, my_ip) or mac in (gw_mac, my_mac):
                    continue
                devices[ip] = {"mac": mac, "name": f"Device-{ip.split('.')[-1]}"}
            monitor    = TrafficMonitor(devices)
            tracker    = ConnectionTracker(devices, iface)
            controller = BandwidthController(iface, monitor)
            controller.set_gateway({"ip": gw_ip, "mac": gw_mac})
            enable_ip_forwarding()
            self.done.emit({"iface": iface, "gw_ip": gw_ip, "gw_mac": gw_mac,
                            "my_ip": my_ip, "devices": devices,
                            "monitor": monitor, "tracker": tracker,
                            "controller": controller})
        except Exception as e:
            self.error.emit(str(e))

class ProfileWorker(QThread):
    done  = pyqtSignal(dict)
    error = pyqtSignal(str)
    def __init__(self, text, ollama_host):
        super().__init__(); self.text = text; self.host = ollama_host
    def run(self):
        try:
            from onboarding import OnboardingManager
            p = OnboardingManager(self.host).run_setup(self.text)
            self.done.emit(p)
        except Exception as e:
            self.error.emit(str(e))

class ChatWorker(QThread):
    reply = pyqtSignal(str)
    def __init__(self, agent, msg):
        super().__init__(); self.agent = agent; self.msg = msg
    def run(self):
        try:
            r = self.agent.chat(self.msg)
            self.reply.emit(r)
        except Exception as e:
            self.reply.emit(f"[Error] {e}")

class DiscoveryWorker(QThread):
    """Scans subnet for new devices periodically."""
    new_devices = pyqtSignal(dict)

    def __init__(self, iface, gw_ip, my_ip, gw_mac, my_mac, known_ips):
        super().__init__()
        self.iface = iface; self.gw_ip = gw_ip; self.my_ip = my_ip
        self.gw_mac = gw_mac; self.my_mac = my_mac; self.known_ips = set(known_ips)

    def run(self):
        try:
            from tool import get_subnet_cidr, discover_clients
            cidr    = get_subnet_cidr(self.iface)
            clients = discover_clients(cidr)
            found   = {}
            for c in clients:
                ip  = c["ip"]; mac = (c.get("mac") or "").lower()
                if ip in (self.gw_ip, self.my_ip): continue
                if mac in (self.gw_mac, self.my_mac): continue
                if ip not in self.known_ips:
                    found[ip] = {"mac": mac, "name": f"Device-{ip.split('.')[-1]}"}
            if found:
                self.new_devices.emit(found)
        except Exception:
            pass



# ═══════════════════════════════════════════════════════════════════
# Cloud Sync Worker
# ═══════════════════════════════════════════════════════════════════

class CloudSyncWorker(QThread):
    """Background thread: link account or test connection without blocking GUI."""
    result = pyqtSignal(bool, str)  # (ok, message)

    def __init__(self, sync, action='test', token=None, email=None, password=None):
        super().__init__()
        self.sync     = sync
        self.action   = action
        self.token    = token
        self.email    = email
        self.password = password

    def run(self):
        if self.action == 'save' and self.token:
            self.sync.set_token(self.token)
            ok, msg = self.sync.test_connection()
        elif self.action == 'link' and self.email and self.password:
            ok, msg = self.sync.link_account(self.email, self.password)
        else:
            ok, msg = self.sync.test_connection()
        self.result.emit(ok, msg)


# ═══════════════════════════════════════════════════════════════════
# Login / Sign-up Page
# ═══════════════════════════════════════════════════════════════════

WEBSITE_URL = 'https://netmind.storephoenix94.workers.dev'
BACKEND_URL = 'https://backend-netmindweb.onrender.com'
LOCK_FILE   = '/tmp/netmind-app.lock'


def _acquire_lock():
    """Return True if this is the only instance, False if another is already running."""
    try:
        if os.path.exists(LOCK_FILE):
            with open(LOCK_FILE) as f:
                pid = int(f.read().strip())
            try:
                os.kill(pid, 0)   # signal 0 = just check existence
                return False      # PID alive → already running
            except ProcessLookupError:
                pass              # PID dead → take over the lock
            except PermissionError:
                return False      # PID alive (different user)
        with open(LOCK_FILE, 'w') as f:
            f.write(str(os.getpid()))
        return True
    except Exception:
        return True               # if we can't check, allow launch


def _release_lock():
    try:
        os.remove(LOCK_FILE)
    except Exception:
        pass

class LoginPage(QWidget):
    """Shown on first launch (no saved API key). Blocks access until authenticated."""
    logged_in = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        from cloud_sync import CloudSync
        self._sync             = CloudSync(server_url=BACKEND_URL)
        self._worker           = None
        self._fail_count       = 0
        self._lockout_secs     = 0
        self._lockout_timer    = QTimer(self)
        self._lockout_timer.timeout.connect(self._tick_lockout)
        self._build_ui()

    def _build_ui(self):
        self.setStyleSheet(f"QWidget{{background:{BG0};}}")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setAlignment(Qt.AlignmentFlag.AlignCenter)

        wrap = QFrame()
        wrap.setFixedWidth(460)
        wrap.setStyleSheet(f"""
            QFrame {{
                background:{BG2};
                border:1px solid rgba(255,255,255,.08);
                border-radius:20px;
            }}
        """)
        vl = QVBoxLayout(wrap)
        vl.setContentsMargins(52, 48, 52, 48)
        vl.setSpacing(0)

        icon_lbl = QLabel()
        icon_lbl.setPixmap(make_icon(64).pixmap(64, 64))
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vl.addWidget(icon_lbl)
        vl.addSpacing(18)

        title = lbl("Welcome to NetMind", 22, bold=True, color=TEXT)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vl.addWidget(title)
        vl.addSpacing(6)

        sub = lbl("Sign in to your account to continue", 13, color=TEXT2)
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vl.addWidget(sub)
        vl.addSpacing(36)

        vl.addWidget(lbl("Email", 12, bold=True, color=TEXT2))
        vl.addSpacing(6)
        self.email_field = QLineEdit()
        self.email_field.setPlaceholderText("you@example.com")
        self.email_field.setFixedHeight(44)
        vl.addWidget(self.email_field)
        vl.addSpacing(18)

        vl.addWidget(lbl("Password", 12, bold=True, color=TEXT2))
        vl.addSpacing(6)
        self.pw_field = QLineEdit()
        self.pw_field.setPlaceholderText("••••••••")
        self.pw_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.pw_field.setFixedHeight(44)
        self.pw_field.returnPressed.connect(self._do_login)
        vl.addWidget(self.pw_field)
        vl.addSpacing(10)

        self.err_lbl = lbl("", 12, color=DANGER)
        self.err_lbl.setWordWrap(True)
        self.err_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.err_lbl.setMinimumHeight(20)
        self.err_lbl.hide()
        vl.addWidget(self.err_lbl)
        vl.addSpacing(6)

        self.login_btn = btn("Sign In", "primary")
        self.login_btn.setFixedHeight(46)
        self.login_btn.clicked.connect(self._do_login)
        vl.addWidget(self.login_btn)
        vl.addSpacing(24)

        vl.addWidget(sep())
        vl.addSpacing(24)

        no_acct = lbl("Don't have an account yet?", 12, color=TEXT2)
        no_acct.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vl.addWidget(no_acct)
        vl.addSpacing(10)

        create_btn = btn("Create Account", "outline")
        create_btn.setFixedHeight(40)
        create_btn.clicked.connect(lambda: webbrowser.open(f'{WEBSITE_URL}/register'))
        vl.addWidget(create_btn)

        outer.addWidget(wrap, alignment=Qt.AlignmentFlag.AlignCenter)

    def _do_login(self):
        if self._lockout_secs > 0:
            return
        email = self.email_field.text().strip()
        pw    = self.pw_field.text()
        if not email or not pw:
            self._show_error("Please enter your email and password.")
            return
        self._set_busy(True)
        self._worker = CloudSyncWorker(self._sync, action='link', email=email, password=pw)
        self._worker.result.connect(self._on_result)
        self._worker.start()

    def _on_result(self, ok: bool, msg: str):
        self._set_busy(False)
        if ok:
            self._fail_count = 0
            self.err_lbl.hide()
            self.logged_in.emit()
        else:
            self._fail_count += 1
            self.pw_field.clear()
            self._show_error(msg)
            # Lockout after 3 failures: 10s, 20s, 40s, 60s max
            delay = 0
            if self._fail_count >= 3:
                delay = min(10 * (2 ** (self._fail_count - 3)), 60)
            if delay > 0:
                self._start_lockout(delay)

    def _show_error(self, msg: str):
        self.err_lbl.setText(msg)
        self.err_lbl.show()

    def _set_busy(self, busy: bool):
        self.login_btn.setEnabled(not busy)
        self.login_btn.setText("Signing in…" if busy else "Sign In")
        self.email_field.setEnabled(not busy)
        self.pw_field.setEnabled(not busy)

    def _start_lockout(self, seconds: int):
        self._lockout_secs = seconds
        self.login_btn.setEnabled(False)
        self.login_btn.setText(f"Too many attempts — wait {seconds}s")
        self._show_error(f"Too many failed attempts. Please wait {seconds} seconds.")
        self._lockout_timer.start(1000)

    def _tick_lockout(self):
        self._lockout_secs -= 1
        if self._lockout_secs <= 0:
            self._lockout_timer.stop()
            self.login_btn.setText("Sign In")
            self.login_btn.setEnabled(True)
            self.err_lbl.hide()
        else:
            self.login_btn.setText(f"Wait {self._lockout_secs}s…")


# ═══════════════════════════════════════════════════════════════════
# Onboarding Page
# ═══════════════════════════════════════════════════════════════════

class OnboardingPage(QWidget):
    confirmed = pyqtSignal(dict)   # emits profile when user clicks Confirm

    def __init__(self, ollama_host, parent=None):
        super().__init__(parent)
        self.host    = ollama_host
        self.profile = None
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.setContentsMargins(60, 40, 60, 40)
        root.setSpacing(20)

        # ── Logo + title ──────────────────────────────────────────
        ico = QLabel("🧠"); ico.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ico.setStyleSheet("font-size:64px;background:transparent;")
        root.addWidget(ico)

        title = lbl("Welcome to NetMind", 32, bold=True)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(
            f"font-size:32px;font-weight:900;background:transparent;"
            f"color:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C1},stop:1 {C2});")
        root.addWidget(title)

        sub = lbl("Describe your network in plain language — AI generates your policy automatically.", 14, color=TEXT2)
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setWordWrap(True)
        root.addWidget(sub)

        # ── Input card ────────────────────────────────────────────
        c = card(); cl = QVBoxLayout(c); cl.setSpacing(12)
        root.addWidget(c)

        cl.addWidget(lbl("Describe your situation", 11, bold=True, color=C1))
        self.txt = QTextEdit()
        self.txt.setPlaceholderText(
            "Examples:\n"
            "• We're a coffee shop — customers need fast WiFi, staff PCs secondary\n"
            "• Small office with VoIP — protect call quality above everything\n"
            "• Home network — fair sharing, kids' streaming shouldn't lag gaming")
        self.txt.setFixedHeight(130)
        cl.addWidget(self.txt)

        row = QHBoxLayout(); row.setSpacing(10)
        self.btn_voice = btn("🎤  Voice Input", "ghost")
        self.btn_voice.clicked.connect(self._voice)
        self.btn_gen   = btn("Generate My Policy  →", "primary")
        self.btn_gen.clicked.connect(self._generate)
        row.addWidget(self.btn_voice); row.addStretch(); row.addWidget(self.btn_gen)
        cl.addLayout(row)

        self.err_lbl = lbl("", 12, color=DANGER)
        self.err_lbl.setWordWrap(True)
        self.err_lbl.hide()
        cl.addWidget(self.err_lbl)

        # ── Spinner label ─────────────────────────────────────────
        self.spin_lbl = lbl("⟳  Llama 3.1 is generating your policy…", 13, color=C1)
        self.spin_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spin_lbl.hide()
        root.addWidget(self.spin_lbl)

        # ── Profile preview ───────────────────────────────────────
        self.preview = card(); self.preview.hide()
        pl = QVBoxLayout(self.preview); pl.setSpacing(12)
        root.addWidget(self.preview)

        pl.addWidget(lbl("AI-Generated Policy", 11, bold=True, color=C1))
        self.prof_lbl = lbl("", 13); self.prof_lbl.setWordWrap(True)
        pl.addWidget(self.prof_lbl)

        prow = QHBoxLayout()
        b_redo    = btn("← Redo", "outline")
        b_confirm = btn("Confirm & Start  →", "success")
        b_redo.clicked.connect(self._redo)
        b_confirm.clicked.connect(self._confirm)
        prow.addWidget(b_redo); prow.addStretch(); prow.addWidget(b_confirm)
        pl.addLayout(prow)

    def _generate(self):
        text = self.txt.toPlainText().strip()
        if not text:
            self._show_err("Please describe your network situation first.")
            return
        self.err_lbl.hide()
        self.btn_gen.setEnabled(False)
        self.spin_lbl.show()
        self.preview.hide()
        self._worker = ProfileWorker(text, self.host)
        self._worker.done.connect(self._on_profile)
        self._worker.error.connect(self._on_err)
        self._worker.start()

    def _on_profile(self, profile):
        self.profile = profile
        self.spin_lbl.hide()
        self.btn_gen.setEnabled(True)
        # Build summary text
        bp = profile.get("bandwidth_policy", {})
        rules = profile.get("priority_rules", {})
        on  = [k.replace("_", " ") for k, v in rules.items() if v]
        txt = (f"<b>{profile.get('summary','')}</b><br>"
               f"<i>\"{profile.get('objective','')}\"</i><br><br>"
               f"<b>Rules:</b> {', '.join(on) or 'general'}<br>"
               f"<b>Max/device:</b> {bp.get('max_per_device_kbps',5120)} KB/s  |  "
               f"<b>Min:</b> {bp.get('min_guaranteed_kbps',256)} KB/s  |  "
               f"<b>Type:</b> {profile.get('business_type','general')}")
        self.prof_lbl.setText(txt)
        self.preview.show()

    def _on_err(self, msg):
        self.spin_lbl.hide()
        self.btn_gen.setEnabled(True)
        self._show_err(f"Error: {msg}")

    def _show_err(self, msg):
        self.err_lbl.setText(msg); self.err_lbl.show()

    def _redo(self):
        self.preview.hide()

    def _confirm(self):
        if self.profile:
            self.confirmed.emit(self.profile)

    def _voice(self):
        """Use browser Web Speech or SpeechRecognition."""
        try:
            import speech_recognition as sr
            rec = sr.Recognizer()
            with sr.Microphone() as src:
                self.btn_voice.setText("🔴  Listening…")
                QApplication.processEvents()
                audio = rec.listen(src, timeout=8, phrase_time_limit=10)
            text = rec.recognize_google(audio)
            self.txt.setPlainText(text)
            self.btn_voice.setText("🎤  Voice Input")
        except Exception as e:
            self.btn_voice.setText("🎤  Voice Input")
            self._show_err(f"Voice error: {e}")


# ═══════════════════════════════════════════════════════════════════
# Dashboard Page
# ═══════════════════════════════════════════════════════════════════

class DashboardPage(QWidget):
    request_reconfigure = pyqtSignal()
    request_logout = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.monitor = self.controller = self.tracker = None
        self.autopilot = self.agent = None
        self.metrics_exporter = None      # Prometheus metrics exporter
        self.devices = {}; self.gw_ip = self.my_ip = self.iface = None
        self.gw_mac = self.my_mac = ""
        self.trusted_ips = set()          # IPs excluded from spoofing/monitoring
        self.monitoring = False; self.ollama = "http://localhost:11434"
        self._plan_id = 'free'            # updated after startup plan fetch
        # Cloud sync service — must be created BEFORE _build() so the panel can reference it
        from cloud_sync import CloudSync
        self._cloud_sync = CloudSync(server_url=os.getenv('NM_SERVER_URL', BACKEND_URL))
        self._cloud_sync.on_status_change = self._on_sync_status
        self._build()
        self._dev_timer  = QTimer(self); self._dev_timer.timeout.connect(self._refresh_devices)
        self._ap_timer   = QTimer(self); self._ap_timer.timeout.connect(self._refresh_autopilot)
        self._disc_timer = QTimer(self); self._disc_timer.timeout.connect(self._run_discovery)
        self._sync_timer = QTimer(self); self._sync_timer.timeout.connect(self._refresh_sync_status)

    def _build(self):
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        # ── Header ──────────────────────────────────────────────
        hdr = QFrame(); hdr.setFixedHeight(56)
        hdr.setStyleSheet(f"QFrame{{background:{BG1};border-bottom:1px solid rgba(255,255,255,.07);}}")
        hl = QHBoxLayout(hdr); hl.setContentsMargins(20,0,16,0); hl.setSpacing(12)
        logo = QLabel("🧠  <b>NetMind</b>")
        logo.setStyleSheet(f"font-size:16px;color:{TEXT};background:transparent;")
        logo.setTextFormat(Qt.TextFormat.RichText)
        hl.addWidget(logo)
        self.profile_badge = QLabel()
        self.profile_badge.setStyleSheet(f"font-size:11px;color:{TEXT2};background:{BG3};border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:3px 12px;")
        hl.addWidget(self.profile_badge); hl.addStretch()
        self.pill_sys = self._pill("System")
        self.pill_mon = self._pill("Monitor")
        self.pill_ap  = self._pill("AutoPilot")
        self.pill_cloud = self._pill("Cloud")
        for p in (self.pill_sys, self.pill_mon, self.pill_ap, self.pill_cloud): hl.addWidget(p)
        hl.addSpacing(8)
        self.btn_init  = btn("Initialize","ghost",small=True);  self.btn_init.clicked.connect(self._init)
        self.btn_start = btn("▶ Start","success",small=True);   self.btn_start.setEnabled(False); self.btn_start.clicked.connect(self._start)
        self.btn_stop  = btn("■ Stop","danger",small=True);     self.btn_stop.setEnabled(False);  self.btn_stop.clicked.connect(self._stop)
        self.btn_graf  = btn("📊 Grafana","outline",small=True); self.btn_graf.clicked.connect(self._open_grafana)
        self.btn_recfg = btn("⚙ Config","outline",small=True);  self.btn_recfg.clicked.connect(self._do_reconfigure)
        for b in (self.btn_init, self.btn_start, self.btn_stop, self.btn_graf, self.btn_recfg):
            hl.addWidget(b)
        root.addWidget(hdr)
        # ── Body ────────────────────────────────────────────────
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;}")
        body = QWidget(); bl = QVBoxLayout(body)
        bl.setContentsMargins(16,16,16,16); bl.setSpacing(12)
        scroll.setWidget(body); root.addWidget(scroll)
        # Stats row
        sr = QHBoxLayout(); sr.setSpacing(10)
        self.s_dev  = self._stat("0","Devices")
        self.s_down = self._stat("0","↓ MB/s",C1)
        self.s_up   = self._stat("0","↑ MB/s",C2)
        self.s_lim  = self._stat("0","Limited",C4)
        self.s_blk  = self._stat("0","Blocked",DANGER)
        self.s_ai   = self._stat("0","AI Cycles",C3)
        for s in (self.s_dev,self.s_down,self.s_up,self.s_lim,self.s_blk,self.s_ai):
            sr.addWidget(s[0])
        bl.addLayout(sr)
        # AutoPilot card
        apc = card(); apl = QVBoxLayout(apc)
        ah = QHBoxLayout(); ah.addWidget(lbl("🤖  AutoPilot",13,bold=True)); ah.addStretch()
        baps = btn("Start AP","success",small=True); baps.clicked.connect(self._ap_start)
        bapx = btn("Stop AP","danger",small=True);  bapx.clicked.connect(self._ap_stop)
        ah.addWidget(baps); ah.addWidget(bapx); apl.addLayout(ah)
        self.btn_ap_start = baps
        self.ap_lbl = QLabel("Initialize and start monitoring to activate AutoPilot.")
        self.ap_lbl.setStyleSheet(f"color:{TEXT2};font-size:12px;background:transparent;")
        self.ap_lbl.setWordWrap(True); apl.addWidget(self.ap_lbl)
        bl.addWidget(apc)
        # Device table
        dc = card(); dvl = QVBoxLayout(dc)
        dh = QHBoxLayout(); dh.addWidget(lbl("📡  Connected Devices",13,bold=True)); dh.addStretch()
        rb = btn("⟳ Scan",  "ghost",small=True); rb.clicked.connect(self._run_discovery); dh.addWidget(rb)
        dvl.addLayout(dh)
        self.tbl = QTableWidget(0, 7)
        self.tbl.setHorizontalHeaderLabels(
            ["IP / Name", "↓ KB/s", "↑ KB/s", "Status", "Activity", "Actions", "Trust"])
        self.tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        for i in (1,2,3,5,6):
            self.tbl.horizontalHeader().setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setShowGrid(False)
        self.tbl.setStyleSheet(
            f"QTableWidget {{background:{BG2};gridline-color:transparent;}}"
            f"QTableWidget::item {{padding:6px 8px;border-bottom:1px solid rgba(255,255,255,.05);}}"
            f"QTableWidget::item:selected {{background:rgba(0,212,255,.12);}}"
            f"QHeaderView::section {{background:{BG3};color:{TEXT2};font-size:11px;"
            f"font-weight:700;padding:8px;border:none;border-bottom:2px solid rgba(0,212,255,.3);}}")
        self.tbl.setFixedHeight(300); dvl.addWidget(self.tbl)
        bl.addWidget(dc)
        # Bottom split
        bot = QHBoxLayout(); bot.setSpacing(12)
        # Decisions feed
        decc = card(); decl = QVBoxLayout(decc)
        drow = QHBoxLayout(); drow.addWidget(lbl("📋  AI Decision Log",13,bold=True))
        live = QLabel("● LIVE"); live.setStyleSheet(f"color:{C3};font-size:10px;font-weight:700;background:transparent;")
        drow.addWidget(live); drow.addStretch(); decl.addLayout(drow)
        self.dec_feed = QTextEdit(); self.dec_feed.setReadOnly(True)
        self.dec_feed.setStyleSheet(f"background:{BG1};border:none;font-size:11px;color:{TEXT2};")
        self.dec_feed.setFixedHeight(260); decl.addWidget(self.dec_feed)
        bot.addWidget(decc,1)
        # Chat
        cc = card(); cl = QVBoxLayout(cc)
        cl.addWidget(lbl("💬  AI Agent Chat",13,bold=True))
        self.chat_log = QTextEdit(); self.chat_log.setReadOnly(True)
        self.chat_log.setStyleSheet(f"background:{BG1};border:none;font-size:12px;")
        self.chat_log.setFixedHeight(200)
        self.chat_log.append(f'<span style="color:{C1}"><b>NetMind:</b></span> Hello! Ask me about your network.')
        cl.addWidget(self.chat_log)
        ci = QHBoxLayout(); ci.setSpacing(8)
        self.chat_in = QLineEdit(); self.chat_in.setPlaceholderText("Ask the AI agent… (Enter)")
        self.chat_in.returnPressed.connect(self._chat_send)
        bsend = btn("Send","primary",small=True); bsend.clicked.connect(self._chat_send); self.bsend_chat = bsend
        bana  = btn("Analyze","ghost",small=True); bana.clicked.connect(lambda: self._chat_run("Analyze the current network state briefly."))
        ci.addWidget(self.chat_in); ci.addWidget(bsend); ci.addWidget(bana); cl.addLayout(ci)
        bot.addWidget(cc,1); bl.addLayout(bot)
        # Override
        ovc = card(); ovl = QVBoxLayout(ovc)
        oh = QHBoxLayout(); oh.addWidget(lbl("🎛  Manual Override",13,bold=True)); oh.addStretch()
        brst = btn("Restore All","danger",small=True); brst.clicked.connect(self._restore_all); oh.addWidget(brst)
        ovl.addLayout(oh)
        fg = QHBoxLayout(); fg.setSpacing(8)
        self.ov_ip   = QLineEdit(); self.ov_ip.setPlaceholderText("Device IP  e.g. 192.168.1.50")
        self.ov_down = QLineEdit("1024"); self.ov_down.setFixedWidth(85); self.ov_down.setPlaceholderText("↓ KB/s")
        self.ov_up   = QLineEdit("512");  self.ov_up.setFixedWidth(85);   self.ov_up.setPlaceholderText("↑ KB/s")
        blim = btn("Limit","primary",small=True); blim.clicked.connect(self._ov_limit)
        bblk = btn("Block","danger",small=True);  bblk.clicked.connect(self._ov_block)
        bfre = btn("Free","success",small=True);  bfre.clicked.connect(self._ov_unblock)
        for w in (self.ov_ip,self.ov_down,self.ov_up,blim,bblk,bfre): fg.addWidget(w)
        fg.addStretch(); ovl.addLayout(fg)
        self.ov_msg = lbl("",12); ovl.addWidget(self.ov_msg)
        bl.addWidget(ovc)

        # ── Cloud Sync card ─────────────────────────────────────────
        sc = card(); sl = QVBoxLayout(sc)
        sh = QHBoxLayout()
        sh.addWidget(lbl("☁  Cloud Sync", 13, bold=True))
        self.pill_cloud = self._pill("Cloud")
        sh.addWidget(self.pill_cloud); sh.addStretch()
        sl.addLayout(sh)

        acct_row = QHBoxLayout(); acct_row.setSpacing(12)
        self.sync_status_lbl = lbl("Checking connection…", 12, color=TEXT2)
        self.sync_status_lbl.setWordWrap(True)
        bsignout = btn("Sign Out", "danger", small=True)
        bsignout.setMinimumWidth(90)
        bsignout.clicked.connect(self._do_signout)
        acct_row.addWidget(self.sync_status_lbl, 1)
        acct_row.addWidget(bsignout)
        sl.addLayout(acct_row)
        bl.addWidget(sc)

    def _pill(self,t):
        l=QLabel(f"● {t}"); l.setStyleSheet(f"color:{TEXT2};font-size:11px;font-weight:600;padding:3px 10px;background:transparent;"); return l
    def _set_pill(self,l,on,col=C3):
        l.setStyleSheet(f"color:{col if on else TEXT2};font-size:11px;font-weight:{'700' if on else '600'};padding:3px 10px;background:transparent;")
    def _stat(self,v,lb,col=TEXT):
        c=card(); cl=QVBoxLayout(c); cl.setSpacing(2)
        vl=QLabel(v); vl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vl.setStyleSheet(f"font-size:26px;font-weight:800;color:{col};background:transparent;")
        ll=QLabel(lb); ll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ll.setStyleSheet(f"font-size:10px;color:{TEXT2};font-weight:600;background:transparent;")
        cl.addWidget(vl); cl.addWidget(ll); return c,vl
    def _sv(self,s,v): s[1].setText(str(v))

    def _init(self):
        self.btn_init.setEnabled(False); self.btn_init.setText("Scanning…")
        self._iw=InitWorker(); self._iw.done.connect(self._on_init); self._iw.error.connect(self._on_init_err); self._iw.start()

    def _on_init(self,d):
        self.monitor=d["monitor"]; self.controller=d["controller"]; self.tracker=d["tracker"]
        self.devices=d["devices"]; self.gw_ip=d["gw_ip"]; self.my_ip=d["my_ip"]
        self.gw_mac=d.get("gw_mac",""); self.my_mac=d.get("my_mac","")
        self.iface=d["iface"]
        self.btn_init.setText("✓ Ready"); self._set_pill(self.pill_sys,True); self.btn_start.setEnabled(True)
        self._sv(self.s_dev,len(self.devices))
        self._agent_init_error = ""
        try:
            from net_agent import NetMindAgent; from tool import Config
            self.agent=NetMindAgent(self.monitor,self.controller,Config,ollama_host=self.ollama)
            self.agent.set_protected_ips(self.gw_ip,self.my_ip)
        except ModuleNotFoundError as _e:
            self.agent=None
            self._agent_init_error = "Ollama library not installed. Run: pip3 install ollama --break-system-packages"
            print(f"[Agent] Init failed: {_e}")
        except Exception as _e:
            self.agent=None
            self._agent_init_error = str(_e)
            print(f"[Agent] Init failed: {_e}")

    def _on_init_err(self,e):
        self.btn_init.setEnabled(True); self.btn_init.setText("Initialize"); self._toast(f"Error: {e}",True)

    def _start(self):
        if not self.monitor: return
        import subprocess
        # ── Step 1: Flush stale TC and iptables rules ─────────────────────────
        subprocess.run(f"tc qdisc del dev {self.iface} root 2>/dev/null",
                       shell=True, stderr=subprocess.DEVNULL)
        subprocess.run("iptables -t mangle -F", shell=True, stderr=subprocess.DEVNULL)
        subprocess.run("iptables -F FORWARD",   shell=True, stderr=subprocess.DEVNULL)
        subprocess.run("iptables -P FORWARD ACCEPT", shell=True, stderr=subprocess.DEVNULL)
        subprocess.run("iptables -A FORWARD -j ACCEPT", shell=True, stderr=subprocess.DEVNULL)
        self.controller._tc_active = False
        self.controller.limits.clear()
        # ── Step 2: Start monitors ────────────────────────────────────────────
        self.monitor.start(); self.tracker.start()
        self.controller.set_gateway({"ip": self.gw_ip, "mac": self.gw_mac})
        # ── Step 3: Spoof all non-trusted devices ─────────────────────────────
        for ip, info in self.devices.items():
            if ip in self.trusted_ips: continue
            self.controller.start_spoofing({"ip": ip, "mac": info.get("mac","")})
        # ── Step 4: Start Prometheus metrics exporter ─────────────────────────
        try:
            import glob as _glob
            for _sp in _glob.glob("/home/*/.local/lib/python*/site-packages"):
                if _sp not in sys.path:
                    sys.path.insert(0, _sp)
            from metrics_exporter import MetricsExporter
            self.metrics_exporter = MetricsExporter(self, port=9090)
            self.metrics_exporter.start()
            self._toast("📊 Metrics exporter started on :9090")
        except Exception as _me:
            self._toast(f"⚠ Metrics exporter failed: {_me}", err=True)
        # ── Step 5: Start Cloud Sync ──────────────────────────────────────────
        try:
            self._cloud_sync.set_server_url(BACKEND_URL)
            self._cloud_sync.set_monitor(self.monitor)
            self._cloud_sync.set_controller(self.controller)
            self._cloud_sync.set_devices(self.devices)
            if not self._cloud_sync.is_running():
                self._cloud_sync.start()
            self._sync_timer.start(4000)
        except Exception as _se:
            print(f'[!] Cloud sync start error: {_se}')
        self.monitoring=True; self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)
        self._set_pill(self.pill_mon,True)
        self._dev_timer.start(3000)
        self._ap_timer.start(5000)
        self._disc_timer.start(30000)
        from onboarding import load_profile
        if load_profile(): self._ap_start()

    def _stop(self):
        if QMessageBox.question(self,"Stop","Stop monitoring and restore the network?",
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes: return
        self._dev_timer.stop(); self._ap_timer.stop(); self._disc_timer.stop(); self._sync_timer.stop()
        if self.autopilot: self.autopilot.stop()
        if self.metrics_exporter:
            try: self.metrics_exporter.stop()
            except: pass
            self.metrics_exporter = None
        if self.tracker: self.tracker.running.set()
        if self.monitor: self.monitor.stop()
        if self.controller: self.controller.cleanup()
        from tool import disable_ip_forwarding; disable_ip_forwarding()
        self.monitoring=False; self.btn_start.setEnabled(True); self.btn_stop.setEnabled(False)
        self._set_pill(self.pill_mon,False); self._set_pill(self.pill_ap,False)
        # Clear the device table visually — self.devices is kept intact for next session
        self.tbl.setRowCount(0)
        self._sv(self.s_down, "0.0"); self._sv(self.s_up, "0.0")
        self._sv(self.s_lim, 0);     self._sv(self.s_blk, 0)

    def _ap_start(self):
        if not self._is_paid():
            self._show_upgrade_popup("AI Autopilot"); return
        if not self.monitoring: self._toast("Start monitoring first.",True); return
        from onboarding import load_profile
        if not load_profile(): self._toast("Complete onboarding first.",True); return
        if self.autopilot and self.autopilot._running: return
        from autopilot import AutoPilot
        self.autopilot=AutoPilot(monitor=self.monitor,controller=self.controller,
            conn_tracker=self.tracker,devices=self.devices,
            protected_ips={self.gw_ip,self.my_ip},ollama_host=self.ollama)
        self.autopilot.start(); self._set_pill(self.pill_ap,True,C4)

    def _ap_stop(self):
        if self.autopilot: self.autopilot.stop()
        self._set_pill(self.pill_ap,False)

    def _tbl_btn(self, label, fg_hex, bg_hex):
        """Table action button — uses QPalette so Qt table can't override colors."""
        import re
        b = QPushButton(label)
        b.setFixedHeight(28)
        b.setFont(QFont("Inter", 11, QFont.Weight.Bold))
        # Strip rgba/hex and build a solid color for palette
        b.setStyleSheet(
            f"QPushButton {{background-color:{bg_hex}; color:{fg_hex};"
            f" border:2px solid {fg_hex}; border-radius:5px; padding:0 10px;"
            f" font-size:11px; font-weight:700;}}"
            f"QPushButton:hover {{background-color:{fg_hex}; color:#ffffff;}}"
            f"QPushButton:pressed {{background-color:{fg_hex}; color:#ffffff; border-color:{fg_hex};}}")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        return b

    def _refresh_devices(self):
        if not self.monitor: return
        stats  = self.monitor.get_current_stats() if self.monitor.running else {}
        limits = self.controller.limits if self.controller else {}
        rows=[]; td=tu=0
        for ip, info in self.devices.items():
            u  = stats.get(ip, {"up":0,"down":0})
            dk = round(u.get("down",0), 1); uk = round(u.get("up",0), 1)
            td += dk; tu += uk
            il = ip in limits; ib = il and limits[ip].get("down",999)<=1
            trusted = ip in self.trusted_ips
            if trusted:
                st = "🔒 Trusted"
            elif ib:
                st = "⛔ Blocked"
            elif il:
                st = "🔴 Limited"
            elif dk > 10:
                st = "🟢 Active"
            else:
                st = "⚪ Idle"
            activity = "—"
            if self.tracker and not trusted:
                try: activity = self.tracker.get_summary(ip)
                except: activity = "—"
            rows.append((ip, info.get("name", ip), dk, uk, st, il, ib, activity, trusted))

        self.tbl.setRowCount(len(rows))
        self.tbl.setRowHeight(0, 36)
        for r, (ip, nm, dk, uk, st, il, ib, act, trusted) in enumerate(rows):
            self.tbl.setRowHeight(r, 36)
            # IP/Name
            name_item = QTableWidgetItem(f"{ip}\n{nm}")
            name_item.setFont(QFont("Inter", 10))
            self.tbl.setItem(r, 0, name_item)
            # Bandwidth
            for col, val in [(1, f"{dk}"), (2, f"{uk}")]:
                it = QTableWidgetItem(val)
                it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.tbl.setItem(r, col, it)
            # Status
            st_item = QTableWidgetItem(st)
            st_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.tbl.setItem(r, 3, st_item)
            # Activity
            act_item = QTableWidgetItem(act); act_item.setToolTip(act)
            self.tbl.setItem(r, 4, act_item)
            # ── Action buttons ────────────────────────────────────
            if not trusted:
                aw = QWidget(); aw.setStyleSheet(f"background:{BG2};")
                al = QHBoxLayout(aw); al.setContentsMargins(3,3,3,3); al.setSpacing(4)
                b_lim = self._tbl_btn("Limit",  "#f59e0b", "#3d2f00")
                b_blk = self._tbl_btn("Block",  "#ef4444", "#3d0000")
                b_fre = self._tbl_btn("Free",   "#00ffa3", "#003d26")
                b_lim.clicked.connect(lambda _, i=ip: self._quick_limit(i))
                b_blk.clicked.connect(lambda _, i=ip: self._quick_block(i))
                b_fre.clicked.connect(lambda _, i=ip: self._quick_free(i))
                al.addWidget(b_lim); al.addWidget(b_blk); al.addWidget(b_fre)
                self.tbl.setCellWidget(r, 5, aw)
            else:
                self.tbl.setItem(r, 5, QTableWidgetItem("—"))
            # ── Trust button ──────────────────────────────────────
            tw = QWidget(); tw.setStyleSheet(f"background:{BG2};")
            tl = QHBoxLayout(tw); tl.setContentsMargins(3,3,3,3)
            if trusted:
                b_tr = self._tbl_btn("Untrust", "#94a3b8", "#1c2333")
                b_tr.clicked.connect(lambda _, i=ip: self._untrust(i))
            else:
                b_tr = self._tbl_btn("Trust", "#00d4ff", "#001a26")
                b_tr.clicked.connect(lambda _, i=ip: self._trust(i))
            tl.addWidget(b_tr)
            self.tbl.setCellWidget(r, 6, tw)

        self._sv(self.s_dev, len(rows))
        self._sv(self.s_down, f"{td/1024:.1f}")
        self._sv(self.s_up,   f"{tu/1024:.1f}")
        self._sv(self.s_lim,  sum(1 for *_,il,ib,_,_ in rows if il and not ib))
        self._sv(self.s_blk,  sum(1 for *_,il,ib,_,_ in rows if ib))

    # ── Auto-discovery ────────────────────────────────────────────
    def _run_discovery(self):
        if not self.monitoring: return
        w = DiscoveryWorker(self.iface, self.gw_ip, self.my_ip,
                            self.gw_mac, self.my_mac, self.devices.keys())
        w.new_devices.connect(self._on_new_devices)
        w.start()
        self._dw = w   # keep reference

    def _on_new_devices(self, found: dict):
        """Called when DiscoveryWorker finds new IPs."""
        for ip, info in found.items():
            if ip in self.devices: continue
            self.devices[ip] = info
            # Add to TrafficMonitor and ConnectionTracker
            if self.monitor:
                self.monitor.devices[ip] = info
            if self.tracker:
                from collections import defaultdict
                self.tracker.connections[ip] = {
                    "domains": [], "ips": [], "ports": defaultdict(int),
                    "last_activity": 0}
            # Start spoofing if not trusted
            if ip not in self.trusted_ips and self.controller:
                self.controller.start_spoofing({"ip": ip, "mac": info.get("mac","")})
            # Allow iptables to track this device
            import subprocess
            subprocess.run(f"iptables -A FORWARD -s {ip} -j ACCEPT",
                           shell=True, stderr=subprocess.DEVNULL)
            subprocess.run(f"iptables -A FORWARD -d {ip} -j ACCEPT",
                           shell=True, stderr=subprocess.DEVNULL)
        self._sv(self.s_dev, len(self.devices))
        self._refresh_devices()

    # ── Trusted list ──────────────────────────────────────────────
    def _trust(self, ip):
        """Add device to trusted list — stop spoofing and monitoring it."""
        self.trusted_ips.add(ip)
        # Stop ARP spoofer
        if self.controller and ip in self.controller.spoofers:
            try: self.controller.spoofers[ip].stop()
            except: pass
            self.controller.spoofers.pop(ip, None)
        # Remove any limit
        if self.controller and ip in self.controller.limits:
            self.controller.remove_limit(ip)
        self._toast(f"✓ {ip} is now trusted — not monitored")
        self._refresh_devices()

    def _untrust(self, ip):
        """Remove device from trusted list — resume monitoring."""
        self.trusted_ips.discard(ip)
        if self.monitoring and self.controller and ip in self.devices:
            self.controller.start_spoofing(
                {"ip": ip, "mac": self.devices[ip].get("mac","")})
        self._toast(f"✓ {ip} removed from trusted list")
        self._refresh_devices()


    def _refresh_autopilot(self):
        if not self.autopilot: return
        s=self.autopilot.get_status()
        ago=f"{s.get('last_decision_ago_s','?')}s ago" if s.get('last_decision_ago_s') is not None else "never"
        self.ap_lbl.setText(f"<b>{'🟢 Running' if s.get('running') else '⏸ Stopped'}</b>  ·  "
            f"Decisions: {s.get('decision_count',0)}  ·  Interval: {s.get('interval_seconds',30)}s  ·  Last: {ago}")
        self._sv(self.s_ai,s.get("decision_count",0))
        from autopilot import load_decision_log
        decisions=load_decision_log(15)
        if decisions:
            parts=[]
            for d in reversed(decisions):
                ts=d.get("timestamp","")[-8:]
                acts=[a.get("type","") for a in d.get("actions_taken",[]) if a.get("type")!="get_network_stats"]
                act_s="  ".join(f'<b style="color:{C4}">[{a}]</b>' for a in acts) if acts else "—"
                reason=d.get("reasoning","")[:160]
                parts.append(f'<p style="margin:3px 0"><span style="color:{TEXT2};font-size:10px">{ts}</span>  {act_s}'
                             f'<br><span style="color:{TEXT2};font-size:11px">{reason}</span></p>'
                             f'<hr style="border-color:rgba(255,255,255,.05);margin:2px 0">')
            self.dec_feed.setHtml("".join(parts))

    def _chat_send(self):
        if not self._is_paid():
            self._show_upgrade_popup("AI Agent Chat"); return
        msg=self.chat_in.text().strip()
        if msg: self.chat_in.clear(); self._chat_run(msg)

    def _chat_run(self,msg):
        if not self.agent:
            reason = getattr(self, '_agent_init_error', '') or 'Initialize the system first.'
            self.chat_log.append(f'<span style="color:{DANGER}">Agent not available: {reason}</span>')
            return
        self.chat_log.append(f'<span style="color:{C2}"><b>You:</b></span> {msg}')
        self._cw=ChatWorker(self.agent,msg); self._cw.reply.connect(self._chat_reply); self._cw.start()

    def _chat_reply(self,r):
        self.chat_log.append(f'<span style="color:{C1}"><b>NetMind:</b></span> {r}')
        self.chat_log.verticalScrollBar().setValue(self.chat_log.verticalScrollBar().maximum())

    def _ov_limit(self):
        ip=self.ov_ip.text().strip()
        if not ip: return
        self._enforce_device_limit(ip)
        try:
            d,u=int(self.ov_down.text()),int(self.ov_up.text())
            ok=self.controller.apply_limit(ip,d,u) if self.controller else False
            self._ov_msg(f"✓ Limited {ip}" if ok else "Not initialized",not ok)
        except Exception as e: self._ov_msg(str(e),True)

    def _ov_block(self):
        ip=self.ov_ip.text().strip()
        self._enforce_device_limit(ip)
        ok=self.controller.apply_limit(ip,1,1) if self.controller and ip else False
        self._ov_msg(f"⛔ Blocked {ip}" if ok else "Failed",not ok)

    def _ov_unblock(self):
        ip=self.ov_ip.text().strip()
        if self.controller and ip: self.controller.remove_limit(ip); self._ov_msg(f"✓ Freed {ip}")

    def _restore_all(self):
        if not self.controller: return
        ips=list(self.controller.limits.keys())
        [self.controller.remove_limit(i) for i in ips]; self._ov_msg(f"✓ Restored {len(ips)} devices")

    def _quick_limit(self,ip): self.ov_ip.setText(ip); self._ov_limit()
    def _quick_block(self,ip): self.ov_ip.setText(ip); self._ov_block()
    def _quick_free(self,ip):  self.ov_ip.setText(ip); self._ov_unblock()

    def _ov_msg(self,t,err=False):
        self.ov_msg.setText(t)
        self.ov_msg.setStyleSheet(f"color:{DANGER if err else C3};font-size:12px;background:transparent;")
        QTimer.singleShot(4000,lambda:self.ov_msg.clear())

    def _toast(self,t,err=False): self._ov_msg(t,err)

    def _do_signout(self):
        from cloud_sync import delete_api_key
        try:
            self._cloud_sync.stop()
        except Exception:
            pass
        delete_api_key()
        self.request_logout.emit()

    def _sync_status(self, msg, error=False):
        col = DANGER if error else C3
        self.sync_status_lbl.setText(msg)
        self.sync_status_lbl.setStyleSheet(f'color:{col};font-size:12px;background:transparent;')

    def _on_sync_status(self, status):
        """Called by CloudSync when connection status changes."""
        messages = {
            'online':       ('🟢 Online — syncing live data to dashboard.', C3,   True),
            'connecting':   ('🟡 Connecting…',                              C4,   False),
            'error':        ('🔴 Auth error — re-enter your credentials.',  DANGER, False),
            'disconnected': ('⚪ Not connected to cloud.',                   TEXT2, False),
        }
        msg, col, on = messages.get(status, ('Unknown', TEXT2, False))
        QTimer.singleShot(0, lambda: (
            self._sync_status(msg, error=(col == DANGER)),
            self._set_pill(self.pill_cloud, on, col),
        ))

    def _refresh_sync_status(self):
        """Keep cloud sync devices list current."""
        if self._cloud_sync and self._cloud_sync.is_running():
            self._cloud_sync.set_devices(self.devices)

    def set_profile(self, p):
        self.profile_badge.setText(f"⚙  {(p.get('summary') or p.get('objective',''))[:60]}")
        if not self._cloud_sync.is_running():
            self._cloud_sync.set_server_url(BACKEND_URL)
            self._cloud_sync.start()
        if not hasattr(self, '_status_poll_timer'):
            self._status_poll_timer = QTimer(self)
            self._status_poll_timer.timeout.connect(self._poll_cloud_status)
        self._status_poll_timer.start(2000)

    def _poll_cloud_status(self):
        if self._cloud_sync:
            self._on_sync_status(self._cloud_sync.status)

    # ── Plan helpers ─────────────────────────────────────────────────

    def _is_paid(self):
        return getattr(self, '_plan_id', 'free') != 'free'

    def _show_upgrade_popup(self, feature: str):
        m = QMessageBox(self)
        m.setWindowTitle("Upgrade Required")
        m.setIcon(QMessageBox.Icon.Information)
        m.setText(f"🔒  {feature} is a paid feature.")
        m.setInformativeText("Upgrade your plan at netmind.storephoenix94.workers.dev to unlock this.")
        m.exec()

    def _enforce_device_limit(self, new_ip: str = ''):
        """Free tier FIFO: evict oldest controlled device when at cap (5)."""
        if self._is_paid() or not self.controller: return
        limits = self.controller.limits
        # Don't count if we're just updating an existing entry
        if new_ip and new_ip in limits: return
        if len(limits) >= 5:
            oldest = next(iter(limits))
            self.controller.remove_limit(oldest)
            self._ov_msg(f"ℹ Free plan: released {oldest} (5-device cap)", False)

    def _open_grafana(self, _=None):
        if not self._is_paid():
            self._show_upgrade_popup("Prometheus + Grafana"); return
        webbrowser.open(GRAFANA_URL)

    def _do_reconfigure(self, _=None):
        if not self._is_paid():
            self._show_upgrade_popup("Custom AI Rules"); return
        self.request_reconfigure.emit()

    def set_plan(self, plan_id: str):
        self._plan_id = plan_id
        is_paid = plan_id != 'free'

        _base_s  = "font-size:12px;font-weight:600;border-radius:8px;padding:5px 13px;border:none;"
        _success = f"{_base_s}background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C3},stop:1 #00cc82);color:#0a0f1a;"
        _outline = f"{_base_s}background:transparent;color:{TEXT2};border:1px solid rgba(255,255,255,.12);"
        _primary = f"{_base_s}background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C1},stop:1 {C2});color:#fff;"
        _locked  = f"{_base_s}background:rgba(255,255,255,.04);color:rgba(148,163,184,.30);"

        tip_locked = "🔒 Paid feature — click to learn more"

        # AI Autopilot
        self.btn_ap_start.setStyleSheet(_success if is_paid else _locked)
        self.btn_ap_start.setToolTip("" if is_paid else tip_locked)
        if not is_paid:
            self.ap_lbl.setText("🔒 AI Autopilot is available on paid plans.")

        # Prometheus / Grafana
        self.btn_graf.setStyleSheet(_outline if is_paid else _locked)
        self.btn_graf.setToolTip("" if is_paid else tip_locked)

        # Reconfigure AI rules
        self.btn_recfg.setStyleSheet(_outline if is_paid else _locked)
        self.btn_recfg.setToolTip("" if is_paid else tip_locked)

        # AI Agent Chat
        self.chat_in.setEnabled(is_paid)
        self.bsend_chat.setStyleSheet(_primary if is_paid else _locked)
        self.chat_in.setPlaceholderText(
            "Ask the AI agent… (Enter)" if is_paid
            else "🔒 AI Agent Chat — upgrade to unlock"
        )

    def set_ollama(self,h): self.ollama=h

    def cleanup(self):
        self._dev_timer.stop(); self._ap_timer.stop(); self._sync_timer.stop()
        try: self._ap_stop()
        except: pass
        try: self._cloud_sync.stop()
        except: pass
        try:
            if self.tracker: self.tracker.running.set()
            if self.monitor: self.monitor.stop()
            if self.controller: self.controller.cleanup()
            from tool import disable_ip_forwarding; disable_ip_forwarding()
        except: pass
        for d in pathlib.Path(BASE).rglob("__pycache__"): shutil.rmtree(d, ignore_errors=True)
        for f in pathlib.Path(BASE).rglob("*.pyc"):
            try: f.unlink(missing_ok=True)
            except OSError: pass


# ═══════════════════════════════════════════════════════════════════
# Custom Frameless Title Bar
# ═══════════════════════════════════════════════════════════════════

class TitleBar(QFrame):
    def __init__(self, win):
        super().__init__(win)
        self._win = win; self._drag = None
        self.setFixedHeight(44)
        self.setStyleSheet(f"QFrame{{background:{BG1};border-bottom:1px solid rgba(255,255,255,.07);}}")
        hl = QHBoxLayout(self); hl.setContentsMargins(14, 0, 8, 0); hl.setSpacing(8)

        # Icon + title (only shown on onboarding; dashboard has its own header)
        self._ico = QLabel("🧠"); self._ico.setStyleSheet("font-size:22px;background:transparent;")
        self._ttl = QLabel("NetMind")
        self._ttl.setStyleSheet(f"font-size:14px;font-weight:800;color:{TEXT};background:transparent;letter-spacing:-0.3px;")
        self._badge = QLabel("AI Autopilot")
        self._badge.setStyleSheet(f"font-size:10px;font-weight:700;color:{C1};background:rgba(0,212,255,.1);"
                                   f"border:1px solid rgba(0,212,255,.25);border-radius:8px;padding:2px 8px;")
        hl.addWidget(self._ico); hl.addWidget(self._ttl); hl.addWidget(self._badge)
        hl.addStretch()

        bstyle = (f"QPushButton{{background:transparent;border:none;color:{TEXT2};"
                  f"font-size:13px;border-radius:5px;padding:3px 8px;min-width:26px;}}"
                  f"QPushButton:hover{{background:rgba(255,255,255,.08);color:{TEXT};}}")
        xstyle = (f"QPushButton{{background:transparent;border:none;color:{TEXT2};"
                  f"font-size:13px;border-radius:5px;padding:3px 8px;min-width:26px;}}"
                  f"QPushButton:hover{{background:#c02020;color:#fff;}}")

        for txt, slot, st in [("─", win.showMinimized, bstyle),
                               ("□", self._toggle_max,  bstyle),
                               ("✕", win.close,         xstyle)]:
            b = QPushButton(txt); b.setStyleSheet(st); b.clicked.connect(slot)
            hl.addWidget(b)

    def _toggle_max(self):
        self._win.showNormal() if self._win.isMaximized() else self._win.showMaximized()

    def set_onboarding_mode(self, yes):
        for w in (self._ico, self._ttl, self._badge):
            w.setVisible(yes)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self._win.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag and e.buttons() == Qt.MouseButton.LeftButton:
            self._win.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e): self._drag = None
    def mouseDoubleClickEvent(self, e): self._toggle_max()


# ═══════════════════════════════════════════════════════════════════
# Main Application Window
# ═══════════════════════════════════════════════════════════════════

class NetMindWindow(QMainWindow):
    def __init__(self, ollama_host="http://localhost:11434"):
        super().__init__()
        self.ollama = ollama_host
        self.setWindowTitle("NetMind")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setWindowIcon(make_icon(64))
        self.setMinimumSize(1100, 720)

        # Center on screen
        scr = QGuiApplication.primaryScreen().availableGeometry()
        self.resize(min(1500, scr.width() - 80), min(900, scr.height() - 60))
        self.move((scr.width() - self.width()) // 2, (scr.height() - self.height()) // 2)

        # Root
        root = QWidget(); self.setCentralWidget(root)
        root.setStyleSheet(f"QWidget{{background:{BG0};}}")
        vbox = QVBoxLayout(root); vbox.setContentsMargins(0,0,0,0); vbox.setSpacing(0)

        # Title bar
        self.tbar = TitleBar(self); vbox.addWidget(self.tbar)

        # Stacked pages
        self.stack = QStackedWidget(); vbox.addWidget(self.stack)

        self.login_page = LoginPage()
        self.ob_page    = OnboardingPage(ollama_host)
        self.dash_page  = DashboardPage()
        self.dash_page.set_ollama(ollama_host)
        self.stack.addWidget(self.login_page)  # index 0
        self.stack.addWidget(self.ob_page)     # index 1
        self.stack.addWidget(self.dash_page)   # index 2

        self.login_page.logged_in.connect(self._on_logged_in)
        self.ob_page.confirmed.connect(self._on_onboarding_done)
        self.dash_page.request_reconfigure.connect(self._go_onboarding)
        self.dash_page.request_logout.connect(self._on_logout)

        # Route based on saved auth state
        from core.cloud_sync import load_api_key
        from onboarding import load_profile
        if load_api_key():
            profile = load_profile()
            if profile:
                self._show_dashboard(profile)
            else:
                self._go_onboarding()
        else:
            self._go_login()

        # System tray
        self._setup_tray()

    # ── Page navigation ──────────────────────────────────────────
    def _go_login(self):
        self.stack.setCurrentIndex(0)
        self.tbar.set_onboarding_mode(True)

    def _on_logout(self):
        self.stack.setCurrentIndex(0)
        self.tbar.set_onboarding_mode(True)
        # Clear login fields so user starts fresh
        self.login_page.email_field.clear()
        self.login_page.pw_field.clear()
        self.login_page.err_lbl.hide()

    def _on_logged_in(self):
        # Token is now saved on disk — push it into DashboardPage's sync instance
        from core.cloud_sync import load_api_key
        token = load_api_key()
        if token:
            self.dash_page._cloud_sync.set_token(token)
        from onboarding import load_profile, save_profile, DEFAULT_PROFILE
        profile = load_profile()
        if not profile:
            # No profile saved — create a default one so the user skips onboarding
            profile = dict(DEFAULT_PROFILE)
            save_profile(profile)
        self._show_dashboard(profile)

    def _go_onboarding(self):
        self.stack.setCurrentIndex(1)
        self.tbar.set_onboarding_mode(True)

    def _on_onboarding_done(self, profile):
        self._show_dashboard(profile)

    def _show_dashboard(self, profile):
        self.dash_page.set_profile(profile)
        self.stack.setCurrentIndex(2)
        self.tbar.set_onboarding_mode(False)  # dashboard has its own header
        self._fetch_plan()

    def _fetch_plan(self):
        import threading
        from core.cloud_sync import load_api_key, _http
        BACKEND = BACKEND_URL
        def _run():
            try:
                token = load_api_key()
                if not token: return
                code, body = _http('GET', f'{BACKEND}/api/tool/plan', token)
                plan_id = body.get('plan_id', 'free') if code == 200 else 'free'
            except Exception:
                plan_id = 'free'
            from PyQt6.QtCore import QMetaObject, Qt, Q_ARG
            QMetaObject.invokeMethod(self, '_apply_plan', Qt.ConnectionType.QueuedConnection,
                                     Q_ARG(str, plan_id))
        threading.Thread(target=_run, daemon=True).start()

    @pyqtSlot(str)
    def _apply_plan(self, plan_id: str):
        self.dash_page.set_plan(plan_id)

    # ── System Tray ──────────────────────────────────────────────
    def _setup_tray(self):
        if not QSystemTrayIcon.isSystemTrayAvailable(): return
        self.tray = QSystemTrayIcon(make_icon(32), self)
        self.tray.setToolTip("NetMind — AI Bandwidth Manager")
        m = QMenu()
        m.setStyleSheet(f"QMenu{{background:{BG2};border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:4px;}}"
                        f"QMenu::item{{padding:8px 20px;border-radius:4px;}}"
                        f"QMenu::item:selected{{background:rgba(0,212,255,.15);}}")
        a_show = QAction("Show NetMind", self); a_show.triggered.connect(self._show_from_tray)
        a_graf = QAction("Open Grafana",  self); a_graf.triggered.connect(lambda: webbrowser.open(GRAFANA_URL))
        a_quit = QAction("Quit",          self); a_quit.triggered.connect(self._quit)
        m.addAction(a_show); m.addAction(a_graf); m.addSeparator(); m.addAction(a_quit)
        self.tray.setContextMenu(m)
        self.tray.activated.connect(lambda r: self._show_from_tray() if r == QSystemTrayIcon.ActivationReason.Trigger else None)
        self.tray.show()

    def _show_from_tray(self):
        self.showNormal(); self.raise_(); self.activateWindow()

    # ── Close / Quit ─────────────────────────────────────────────
    def closeEvent(self, e):
        if hasattr(self, 'tray') and self.tray.isVisible():
            self.hide()
            self.tray.showMessage("NetMind", "Running in background — right-click tray icon to quit.",
                                  QSystemTrayIcon.MessageIcon.Information, 2500)
            e.ignore()
        else:
            self._quit()

    def _quit(self, _=None):
        self.dash_page.cleanup()
        if hasattr(self, 'tray'): self.tray.hide()
        QApplication.quit()


# ═══════════════════════════════════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════════════════════════════════

def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")

    app = QApplication(sys.argv)
    app.setApplicationName("NetMind")
    app.setApplicationDisplayName("NetMind")
    app.setOrganizationName("NetMind")
    app.setStyleSheet(DARK_STYLE)

    # ── Single-instance guard ─────────────────────────────────────────────────
    if not _acquire_lock():
        box = QMessageBox()
        box.setWindowTitle("NetMind")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText("NetMind is already running.")
        box.setInformativeText("Check the system tray icon to open or manage the app.")
        box.setStyleSheet(DARK_STYLE)
        box.exec()
        sys.exit(0)
    import atexit
    atexit.register(_release_lock)

    # Splash
    splash_px = QPixmap(480, 260)
    splash_px.fill(QColor(BG1))
    sp = QPainter(splash_px)
    sp.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, 480, 260)
    g.setColorAt(0, QColor(C1)); g.setColorAt(1, QColor(C2))
    sp.setPen(QPen(QColor(C1))); sp.setBrush(QBrush(g))
    sp.drawEllipse(190, 20, 100, 100)
    sp.setPen(QPen(QColor("white")))
    sp.setFont(QFont("Inter", 42, QFont.Weight.Black))
    sp.drawText(190, 20, 100, 100, Qt.AlignmentFlag.AlignCenter, "N")
    sp.setPen(QPen(QColor(TEXT)))
    sp.setFont(QFont("Inter", 24, QFont.Weight.Bold))
    sp.drawText(0, 130, 480, 40, Qt.AlignmentFlag.AlignCenter, "NetMind")
    sp.setPen(QPen(QColor(TEXT2)))
    sp.setFont(QFont("Inter", 12))
    sp.drawText(0, 172, 480, 30, Qt.AlignmentFlag.AlignCenter, "AI-Powered Bandwidth Management")
    sp.setPen(QPen(QColor(C1)))
    sp.setFont(QFont("Inter", 11))
    sp.drawText(0, 218, 480, 26, Qt.AlignmentFlag.AlignCenter, "Loading…")
    sp.end()

    splash = QSplashScreen(splash_px, Qt.WindowType.WindowStaysOnTopHint)
    splash.show(); app.processEvents()

    # Ollama host from env
    ollama = os.getenv("OLLAMA_HOST", "http://localhost:11434")

    win = NetMindWindow(ollama_host=ollama)
    win.show()
    splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
